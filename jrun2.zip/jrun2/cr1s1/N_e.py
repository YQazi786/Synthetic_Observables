import numpy as np
import matplotlib.pyplot as plt
import pencil as pc

#Uses Wolfire et al. 'Neutral Atomic Phases of the ISM in the Galaxy' to describe the number of electrons in the cold ionised medium (CIM) and warm ionised medium (WIM)
#Values of parameters are all for the solar circle, R=8.5kpc
#G0 from Table 2 Wolfire
G0 = 1

#xi from table 2 Wolfire
xiCR = 1
xiXR = 1
xit = xiCR + xiXR

#phiPAH from page 307 Wolfire
phiPAH = 0.5

#metallicity from Wolfire
Zd = 1

#Temperature from simulation
var = pc.read.var('VAR1.h5',trimall=True,magic=['tt'])
par = pc.read.param()
T = var.tt*par.unit_temperature



def Ne(xit,T,G0,Zd,phiPAH):
    '''
    inputs:
        Total ionisation rate, xit
        Temperature, T
        Scaled intensity of FUV interstellar radiation field, G0
        Metallicity, Zd
        Scaling parameter of the PAH collision rates, phiPAH
    '''
    T2 = T/100

    return (2.4e-3 * np.sqrt(xit) * T2**(0.25) * np.sqrt(G0)) / (np.sqrt(Zd) * phiPAH)  



